<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

jimport('joomla.application.component.controller');

class K2ControllerExtraFields extends K2Controller
{
    public function display($cachable = false, $urlparams = [])
    {
        K2Request::setVar('view', 'extrafields');
        parent::display();
    }

    public function publish()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->publish();
    }

    public function unpublish()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->unpublish();
    }

    public function saveorder()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->saveorder();

        $document = Joomla\CMS\Factory::getDocument();
        if ($document->getType() == 'raw') {
            echo '1';

            return $this;
        }

        $this->setRedirect('index.php?option=com_k2&view=extrafields', Joomla\CMS\Language\Text::_('K2_NEW_ORDERING_SAVED'));

        return null;
    }

    public function orderup()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->orderup();
    }

    public function orderdown()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->orderdown();
    }

    public function remove()
    {
        K2Request::checkToken() || jexit('Invalid Token');
        $model = $this->getModel('extraFields');
        $model->remove();
    }

    public function add()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $app->redirect('index.php?option=com_k2&view=extrafield');
    }

    public function edit()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $cid = K2Request::getVar('cid');
        $app->redirect('index.php?option=com_k2&view=extrafield&cid='.$cid[0]);
    }
}
