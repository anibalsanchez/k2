<?php
/**
 * @version    2.x (rolling release)
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2009 - 2025 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL: https://gnu.org/licenses/gpl.html
 */

// no direct access
defined('_JEXEC') || die;

?>

<form action="index.php" enctype="multipart/form-data" method="post" name="adminForm" id="adminForm">
    <div class="xmlParamsFields k2GenericForm">
        <h3>
            <?php if ($this->row->id): ?>
            <?php echo Joomla\CMS\Language\Text::_('K2_EDIT_TAG'); ?>
            <?php else: ?>
            <?php echo Joomla\CMS\Language\Text::_('K2_ADD_NEW_TAG'); ?>
            <?php endif; ?>
        </h3>

        <ul class="adminformlist">
            <li>
                <div class="paramLabel">
                    <label for="name"><?php echo Joomla\CMS\Language\Text::_('K2_NAME'); ?></label>
                </div>
                <div class="paramValue">
                    <input class="text_area k2TitleBox" type="text" name="name" id="name" value="<?php echo $this->row->name; ?>" size="50" maxlength="250" />
                </div>
            </li>
            <li>
                <div class="paramLabel">
                    <label><?php echo Joomla\CMS\Language\Text::_('K2_PUBLISHED'); ?></label>
                </div>
                <div class="paramValue">
                    <?php echo $this->lists['published']; ?>
                </div>
            </li>
            <li>
                <div class="paramLabel">
                    <label for="name"><?php echo Joomla\CMS\Language\Text::_('K2_DESCRIPTION'); ?></label>
                </div>
                <div class="paramValue">
                    <textarea name="description" rows="5" cols="50" class="textarea"><?php echo $this->row->description; ?></textarea>
                </div>
            </li>
        </ul>
    </div>

    <input type="hidden" name="id" value="<?php echo $this->row->id; ?>" />
    <input type="hidden" name="option" value="com_k2" />
    <input type="hidden" name="view" value="tag" />
    <input type="hidden" name="task" value="<?php echo K2Request::getVar('task'); ?>" />
    <?php echo Joomla\CMS\HTML\HTMLHelper::_('form.token'); ?>
</form>
