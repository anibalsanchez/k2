<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

require_once JPATH_ADMINISTRATOR.'/components/com_k2/elements/base.php';

class K2ElementItemForm extends K2Element
{
    public function fetchElement($name, $value, &$node, $control_name)
    {
        if (version_compare(JVERSION, '3.5', 'ge')) {
            Joomla\CMS\HTML\HTMLHelper::_('behavior.framework');
        }

        $document = Joomla\CMS\Factory::getDocument();
        $document->addScriptDeclaration("
        	/* Mootools Snippet */
			window.addEvent('domready', function() {
				if ($('request-options')) {
					$$('.panel')[0].setStyle('display', 'none');
				}
				if ($('jform_browserNav')) {
					$('jform_browserNav').setProperty('value', 2);
					$('jform_browserNav').getElements('option')[0].destroy();
				}
				if ($('browserNav')) {
					$('browserNav').setProperty('value', 2);
					options = $('browserNav').getElements('option');
					if (options.length == 3) {
						options[0].remove();
					}
				}
			});
		");

        return '';
    }

    public function fetchTooltip($label, $description, &$node, $control_name, $name)
    {
        return '';
    }
}

class JFormFielditemform extends K2ElementItemForm
{
    public $type = 'itemform';
}

class JElementitemform extends K2ElementItemForm
{
    public $_name = 'itemform';
}
