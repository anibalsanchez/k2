<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

jimport('joomla.application.component.model');

Joomla\CMS\Table\Table::addIncludePath(JPATH_COMPONENT.'/tables');

class K2ModelItem extends K2Model
{
    public function getData()
    {
        $cid = K2Request::getVar('cid');
        $row = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
        $row->load($cid);

        return $row;
    }

    public function save($front = false)
    {
        $app = Joomla\CMS\Factory::getApplication();
        jimport('joomla.filesystem.file');
        jimport('joomla.filesystem.folder');
        jimport('joomla.filesystem.archive');
        $db = Joomla\CMS\Factory::getDbo();
        $user = Joomla\CMS\Factory::getUser();
        $row = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        $nullDate = $db->getNullDate();

        // Plugin Events
        Joomla\CMS\Plugin\PluginHelper::importPlugin('k2');
        Joomla\CMS\Plugin\PluginHelper::importPlugin('content');
        Joomla\CMS\Plugin\PluginHelper::importPlugin('finder');
        $dispatcher = JDispatcher::getInstance();

        if (!$row->bind(K2Request::getPost())) {
            $app->enqueueMessage($row->getError(), 'error');
            $app->redirect('index.php?option=com_k2&view=items');
        }

        if ($front && $row->id == null) {
            JLoader::register('K2HelperPermissions', JPATH_SITE.'/components/com_k2/helpers/permissions.php');
            if (!K2HelperPermissions::canAddItem($row->catid)) {
                $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_YOU_ARE_NOT_ALLOWED_TO_POST_TO_THIS_CATEGORY_SAVE_FAILED'), 'error');
                $app->redirect('index.php?option=com_k2&view=item&task=add&tmpl=component');
            }
        }

        $isNew = !(bool) $row->id;

        // If the item is not new, retrieve its saved data
        $savedRow = new stdClass();
        if (!$isNew) {
            $id = K2Request::getInt('id');
            $savedRow = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
            $savedRow->load($id);
            // Frontend only
            if ($front) {
                $published = $savedRow->published;
                $featured = $savedRow->featured;
            }
        }

        if ($params->get('mergeEditors')) {
            $text = K2Request::getVar('text', '', 'post', 'string', 2);
            if ($params->get('xssFiltering')) {
                $filter = new JFilterInput([], [], 1, 1, 0);
                $text = $filter->clean($text);
            }

            $pattern = '#<hr\s+id=("|\')system-readmore("|\')\s*\/*>#i';
            $tagPos = preg_match($pattern, $text);
            if ($tagPos == 0) {
                $row->introtext = $text;
                $row->fulltext = '';
            } else {
                [$row->introtext, $row->fulltext] = preg_split($pattern, $text, 2);
            }
        } else {
            $row->introtext = K2Request::getVar('introtext', '', 'post', 'string', 2);
            $row->fulltext = K2Request::getVar('fulltext', '', 'post', 'string', 2);
            if ($params->get('xssFiltering')) {
                $filter = new JFilterInput([], [], 1, 1, 0);
                $row->introtext = $filter->clean($row->introtext);
                $row->fulltext = $filter->clean($row->fulltext);
            }
        }

        if ($row->id) {
            $datenow = Joomla\CMS\Factory::getDate();
            $row->modified = (K2_JVERSION == '15') ? $datenow->toMySQL() : $datenow->toSql();
            $row->modified_by = $user->get('id');
        } else {
            $row->ordering = $row->getNextOrder('catid = '.(int) $row->catid.' AND trash = 0');
            if ($row->featured) {
                $row->featured_ordering = $row->getNextOrder('featured = 1 AND trash = 0', 'featured_ordering');
            }
        }

        // Author
        $row->created_by = $row->created_by ?: $user->get('id');
        if ($front) {
            $K2Permissions = K2Permissions::getInstance();
            if (!$K2Permissions->permissions->get('editAll')) {
                $row->created_by = $user->get('id');
            }
        }

        if ($row->created && strlen(trim($row->created)) <= 10) {
            $row->created .= ' 00:00:00';
        }

        $config = Joomla\CMS\Factory::getConfig();
        $tzoffset = K2_JVERSION == '30' ? $config->get('offset') : $config->getValue('config.offset');
        $date = Joomla\CMS\Factory::getDate($row->created, $tzoffset);
        $row->created = (K2_JVERSION == '15') ? $date->toMySQL() : $date->toSql();

        if (strlen(trim($row->publish_up)) <= 10) {
            $row->publish_up .= ' 00:00:00';
        }

        $date = Joomla\CMS\Factory::getDate($row->publish_up, $tzoffset);
        $row->publish_up = (K2_JVERSION == '15') ? $date->toMySQL() : $date->toSql();

        if (trim($row->publish_down) == Joomla\CMS\Language\Text::_('K2_NEVER') || trim($row->publish_down) === '') {
            $row->publish_down = $nullDate;
        } else {
            if (strlen(trim($row->publish_down)) <= 10) {
                $row->publish_down .= ' 00:00:00';
            }

            $date = Joomla\CMS\Factory::getDate($row->publish_down, $tzoffset);
            $row->publish_down = (K2_JVERSION == '15') ? $date->toMySQL() : $date->toSql();
        }

        $metadata = K2Request::getVar('meta', null, 'post', 'array');
        if (is_array($metadata)) {
            $txt = [];
            foreach ($metadata as $k => $v) {
                if ($k == 'description') {
                    $row->metadesc = $v;
                } elseif ($k == 'keywords') {
                    $row->metakey = $v;
                } else {
                    $txt[] = sprintf('%s=%s', $k, $v);
                }
            }

            $row->metadata = implode("\n", $txt);
        }

        if (!$row->check()) {
            $app->enqueueMessage($row->getError(), 'error');
            $app->redirect('index.php?option=com_k2&view=item&cid='.$row->id);
        }

        // Trigger K2 plugins
        $result = $dispatcher->trigger('onBeforeK2Save', [&$row, $isNew]);

        if (in_array(false, $result, true)) {
            JError::raiseError(500, $row->getError());

            return false;
        }

        // Trigger content & finder plugins before the save event
        $dispatcher->trigger('onContentBeforeSave', ['com_k2.item', $row, $isNew]);
        $dispatcher->trigger('onFinderBeforeSave', ['com_k2.item', $row, $isNew]);

        // JoomFish front-end editing compatibility
        if ($app->isClient('site') && Joomla\CMS\Filesystem\File::exists(JPATH_ADMINISTRATOR.'/components/com_joomfish/joomfish.php')) {
            $tmpRow = version_compare(phpversion(), '5.0') < 0 ? $row : clone $row;
        }

        if (!$row->store()) {
            $app->enqueueMessage($row->getError(), 'error');
            $app->redirect('index.php?option=com_k2&view=items');
        }

        // JoomFish front-end editing compatibility
        if ($app->isClient('site') && Joomla\CMS\Filesystem\File::exists(JPATH_ADMINISTRATOR.'/components/com_joomfish/joomfish.php')) {
            $itemID = $row->id;
            $row = $tmpRow;
            $row->id = $itemID;
        }

        if (!$params->get('disableCompactOrdering')) {
            $row->reorder('catid = '.(int) $row->catid.' AND trash = 0');
        }

        if ($row->featured && !$params->get('disableCompactOrdering')) {
            $row->reorder('featured = 1 AND trash = 0', 'featured_ordering');
        }

        // Tags
        if ($params->get('taggingSystem') === '0' || $params->get('taggingSystem') === '1') {
            // B/C - Convert old options
            $whichTaggingSystem = ($params->get('taggingSystem') !== '' && $params->get('taggingSystem') !== '0') ? 'free' : 'selection';
            $params->set('taggingSystem', $whichTaggingSystem);
        }

        if ($user->gid < 24 && $params->get('lockTags')) {
            $params->set('taggingSystem', 'selection');
        }

        $db->setQuery('DELETE FROM #__k2_tags_xref WHERE itemID='.(int) $row->id);
        $db->execute();

        if ($params->get('taggingSystem') == 'free') {
            if ($user->gid < 24 && $params->get('lockTags')) {
                JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
            }

            $tags = K2Request::getVar('tags', null, 'POST', 'array');
            if (is_array($tags) && count($tags)) {
                $tags = array_unique($tags);
                foreach ($tags as $tag) {
                    $tag = JString::trim($tag);
                    if ($tag) {
                        $tagID = false;
                        $K2Tag = Joomla\CMS\Table\Table::getInstance('K2Tag', 'Table');
                        $K2Tag->name = $tag;
                        // Tag has been filtered and does not exist
                        if ($K2Tag->check()) {
                            $K2Tag->published = 1;
                            if ($K2Tag->store()) {
                                $tagID = $K2Tag->id;
                            }
                        }
                        // Tag has been filtered and it exists so try to find its ID
                        elseif ($K2Tag->name) {
                            $db->setQuery('SELECT id FROM #__k2_tags WHERE name='.$db->Quote($K2Tag->name));
                            $tagID = $db->loadResult();
                        }

                        if ($tagID) {
                            $db->setQuery('INSERT INTO #__k2_tags_xref (`id`, `tagID`, `itemID`) VALUES (NULL, '.(int) $tagID.', '.(int) $row->id.')');
                            $db->execute();
                        }
                    }
                }
            }
        } else {
            $tags = K2Request::getVar('selectedTags', null, 'POST', 'array');
            if (is_array($tags) && count($tags)) {
                foreach ($tags as $tag) {
                    $db->setQuery('INSERT INTO #__k2_tags_xref (`id`, `tagID`, `itemID`) VALUES (NULL, '.(int) $tag.', '.(int) $row->id.')');
                    $db->execute();
                }
            }
        }

        // File Uploads
        $files = K2Request::getFiles();

        // Load class.upload.php
        require_once JPATH_SITE.'/media/k2/assets/vendors/verot/class.upload.php/src/class.upload.php';

        // Image
        if ((int) $params->get('imageMemoryLimit') !== 0) {
            ini_set('memory_limit', (int) $params->get('imageMemoryLimit').'M');
        }

        $existingImage = K2Request::getVar('existingImage');

        if (($files['image']['error'] == 0 || $existingImage) && !K2Request::getBool('del_image')) {
            $image = $files['image']['error'] == 0 ? $files['image'] : JPATH_SITE.'/'.Joomla\CMS\Filesystem\Path::clean($existingImage);

            try {
                $handle = new Verot\Upload\Upload($image);
                $handle->allowed = ['image/*'];
                $handle->forbidden = ['image/bmp', 'image/tiff'];

                if ($handle->uploaded) {
                    // Image params
                    $category = Joomla\CMS\Table\Table::getInstance('K2Category', 'Table');
                    $category->load($row->catid);
                    $cparams = class_exists('JParameter') ? new JParameter($category->params) : new JRegistry($category->params);
                    if ($cparams->get('inheritFrom')) {
                        $masterCategoryID = $cparams->get('inheritFrom');
                        $db->setQuery('SELECT * FROM #__k2_categories WHERE id='.(int) $masterCategoryID, 0, 1);
                        $masterCategory = $db->loadObject();
                        $cparams = class_exists('JParameter') ? new JParameter($masterCategory->params) : new JRegistry($masterCategory->params);
                    }

                    $params->merge($cparams);

                    // --- Original image
                    $savepath = JPATH_SITE.'/media/k2/items/src';

                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = md5('Image'.$row->id);
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->jpeg_quality = 100;

                    $handle->process($savepath);

                    // --- Resized images
                    $savepath = JPATH_SITE.'/media/k2/items/cache';
                    $filename = $handle->file_dst_name_body;

                    // XLarge image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_XL';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');
                    $imageWidth = K2Request::getInt('itemImageXL') ?: $params->get('itemImageXL', '900');

                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    // Large image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_L';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');
                    $imageWidth = K2Request::getInt('itemImageL') ?: $params->get('itemImageL', '600');

                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    // Medium image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_M';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');
                    $imageWidth = K2Request::getInt('itemImageM') ?: $params->get('itemImageM', '400');

                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    // Small image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_S';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');
                    $imageWidth = K2Request::getInt('itemImageS') ?: $params->get('itemImageS', '200');

                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    // XSmall image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_XS';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');
                    $imageWidth = K2Request::getInt('itemImageXS') ?: $params->get('itemImageXS', '100');

                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    // Generic image
                    $handle->file_auto_rename = false;
                    $handle->file_new_name_body = $filename.'_Generic';
                    $handle->file_overwrite = true;
                    $handle->image_convert = 'jpg';
                    $handle->image_ratio_y = true;
                    $handle->image_resize = true;
                    $handle->jpeg_quality = $params->get('imagesQuality', '90');

                    $imageWidth = $params->get('itemImageGeneric', '300');
                    $handle->image_x = $imageWidth;

                    $handle->process($savepath);

                    if ($handle->processed) {
                        if ($files['image']['error'] == 0) {
                            $handle->clean();
                        }
                    } else {
                        throw new RuntimeException($handle->error);
                    }
                }
            } catch (Exception $e) {
                $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_COULD_NOT_UPLOAD_YOUR_IMAGE').$e->getMessage(), 'error');
            }
        }

        if (K2Request::getBool('del_image')) {
            $filename = md5('Image'.$savedRow->id);

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/src/'.$filename.'.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/src/'.$filename.'.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_XS.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_XS.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_S.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_S.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_M.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_M.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_L.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_L.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_XL.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_XL.jpg');
            }

            if (Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_Generic.jpg')) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/items/cache/'.$filename.'_Generic.jpg');
            }

            $row->image_caption = '';
            $row->image_credits = '';
        }

        // Gallery
        if (empty($savedRow->gallery)) {
            $row->gallery = '';
        }

        $flickrGallery = K2Request::getVar('flickrGallery');
        if ($flickrGallery) {
            $row->gallery = '{gallery}'.$flickrGallery.'{/gallery}';
        }

        if (isset($files['gallery']) && $files['gallery']['error'] == 0 && !K2Request::getBool('del_gallery')) {
            try {
                $savepath = JPATH_ROOT.'/media/k2/galleries';

                $handle = new Verot\Upload\Upload($files['gallery']);
                $handle->allowed = [
                    'application/gnutar',
                    'application/gzip',
                    'application/x-bzip',
                    'application/x-bzip2',
                    'application/x-compressed',
                    'application/x-gtar',
                    'application/x-gzip',
                    'application/x-tar',
                    'application/x-zip-compressed',
                    'application/zip',
                    'multipart/x-gzip',
                    'multipart/x-zip',
                ];
                $handle->file_auto_rename = true;

                if ($handle->uploaded) {
                    $handle->process($savepath);
                    if (!$handle->processed) {
                        throw new RuntimeException($handle->error);
                    }

                    if (Joomla\CMS\Filesystem\Folder::exists($savepath.'/'.$row->id)) {
                        Joomla\CMS\Filesystem\Folder::delete($savepath.'/'.$row->id);
                    }

                    if (!JArchive::extract($savepath.'/'.$handle->file_dst_name, $savepath.'/'.$row->id)) {
                        $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_GALLERY_UPLOAD_ERROR_CANNOT_EXTRACT_ARCHIVE'), 'error');
                        $app->redirect('index.php?option=com_k2&view=items');
                    } else {
                        $imageDir = $savepath.'/'.$row->id;
                        $galleryDir = opendir($imageDir);
                        while ($filename = readdir($galleryDir)) {
                            if ($filename !== '.' && $filename !== '..') {
                                $ext = strtolower(Joomla\CMS\Filesystem\File::getExt($filename));
                                $allowedExts = ['gif', 'jpg', 'jpeg', 'png', 'webp'];
                                if (in_array($ext, $allowedExts)) {
                                    $file = str_replace(' ', '_', $filename);
                                    $safefilename = Joomla\CMS\Filesystem\File::makeSafe($file);
                                    rename($imageDir.'/'.$filename, $imageDir.'/'.$safefilename);
                                }
                            }
                        }

                        closedir($galleryDir);
                        $row->gallery = '{gallery}'.$row->id.'{/gallery}';
                    }

                    $archivePath = $savepath.'/'.$handle->file_dst_name;
                    if (Joomla\CMS\Filesystem\File::exists($archivePath)) {
                        Joomla\CMS\Filesystem\File::delete($archivePath);
                    }

                    if ($handle->processed) {
                        $handle->clean();
                    } else {
                        throw new RuntimeException($handle->error);
                    }
                }
            } catch (Exception $e) {
                $app->enqueueMessage($e->getMessage(), 'error');
                $app->redirect('index.php?option=com_k2&view=items');
            }
        }

        if (K2Request::getBool('del_gallery')) {
            if (Joomla\CMS\Filesystem\Folder::exists(JPATH_ROOT.'/media/k2/galleries/'.$savedRow->id)) {
                Joomla\CMS\Filesystem\Folder::delete(JPATH_ROOT.'/media/k2/galleries/'.$savedRow->id);
            }

            $row->gallery = '';
        }

        // === Media ===

        // Allowed filetypes for uploading
        $videoExtensions = [
            'avi',
            'm4v',
            'mkv',
            'mp4',
            'ogv',
            'webm',
        ];
        $audioExtensions = [
            'flac',
            'm4a',
            'mp3',
            'oga',
            'ogg',
            'wav',
        ];
        $validExtensions = array_merge($videoExtensions, $audioExtensions);

        // No stored media & form fields empty for media
        if (empty($savedRow->video) && !K2Request::getVar('embedVideo') && !K2Request::getVar('videoID') && !K2Request::getVar('remoteVideo') && !K2Request::getVar('uploadedVideo')) {
            $row->video = '';
        }

        // There is stored media
        if (!empty($savedRow->video)) {
            $row->video = $savedRow->video;
        }

        // Embed
        if (K2Request::getVar('embedVideo', '', 'post', 'string', JREQUEST_ALLOWRAW)) {
            $row->video = K2Request::getVar('embedVideo', '', 'post', 'string', JREQUEST_ALLOWRAW);
        }

        // Third-party Media Service
        if (K2Request::getVar('videoID')) {
            $provider = K2Request::getWord('videoProvider');
            $videoID = K2Request::getVar('videoID');
            $row->video = '{'.$provider.'}'.$videoID.'{/'.$provider.'}';
        }

        // Browse server or remote media
        if (K2Request::getVar('remoteVideo')) {
            $fileurl = K2Request::getVar('remoteVideo');
            $filetype = Joomla\CMS\Filesystem\File::getExt($fileurl);
            $allVideosTagSuffix = 'remote';
            $row->video = '{'.$filetype.$allVideosTagSuffix.'}'.$fileurl.'{/'.$filetype.$allVideosTagSuffix.'}';
        }

        // Upload media
        if (isset($files['video']) && $files['video']['error'] == 0 && !K2Request::getBool('del_video')) {
            $filename_suffix = $row->modified ?: $row->created;
            $filename = Joomla\CMS\Filesystem\File::stripExt($files['video']['name']);
            if (class_exists('Transliterator')) {
                $tlSetup = Transliterator::create('Any-Latin; Latin-ASCII');
                $filename = $tlSetup->transliterate($filename);
                $filename = strtolower($filename);
            }

            $filename = preg_replace('/[^\p{L}\p{N}_]/u', '_', trim($filename));
            $filename = $filename.'_'.Joomla\CMS\HTML\HTMLHelper::_('date', $filename_suffix, 'Ymd_Hi');
            $filename = preg_replace('/_+/', '_', $filename);

            $filetype = Joomla\CMS\Filesystem\File::getExt($files['video']['name']);

            if (!in_array($filetype, $validExtensions)) {
                $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_INVALID_VIDEO_FILE'), 'error');
                $app->redirect('index.php?option=com_k2&view=items');
            }

            $savepath = in_array($filetype, $videoExtensions) ? JPATH_ROOT.'/media/k2/videos' : JPATH_ROOT.'/media/k2/audio';

            Joomla\CMS\Filesystem\File::upload($files['video']['tmp_name'], $savepath.'/'.$filename.'.'.$filetype);

            $row->video = '{'.$filetype.'}'.$filename.'{/'.$filetype.'}';
        }

        // Delete media
        if (K2Request::getBool('del_video')) {
            preg_match_all('#^{(.*?)}(.*?){#', $savedRow->video, $matches, PREG_PATTERN_ORDER);

            $mediaType = $matches[1][0];
            $mediaFile = $matches[2][0];

            if (in_array($mediaType, $videoExtensions) && Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/videos/'.$mediaFile.'.'.$mediaType)) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/videos/'.$mediaFile.'.'.$mediaType);
            }

            if (in_array($mediaType, $audioExtensions) && Joomla\CMS\Filesystem\File::exists(JPATH_ROOT.'/media/k2/audio/'.$mediaFile.'.'.$mediaType)) {
                Joomla\CMS\Filesystem\File::delete(JPATH_ROOT.'/media/k2/audio/'.$mediaFile.'.'.$mediaType);
            }

            $row->video = '';
        }

        // Media Caption & Credits
        if (!$row->video) {
            $row->video_caption = '';
            $row->video_credits = '';
        }

        // === Extra fields ===
        if ($params->get('showExtraFieldsTab') || $app->isClient('administrator')) {
            $objects = [];

            // TODO: $variables = JRequest::get('post', 2); ?
            $variables = K2Request::getPost();

            foreach ($variables as $key => $value) {
                if ((bool) JString::stristr($key, 'K2ExtraField_')) {
                    $object = new stdClass();
                    $object->id = substr($key, 13);
                    if (is_string($value)) {
                        $value = trim($value);
                    }

                    $object->value = $value;
                    $objects[] = $object;
                }
            }

            $csvFiles = K2Request::getFiles();
            foreach ($csvFiles as $key => $file) {
                if ((bool) JString::stristr($key, 'K2ExtraField_')) {
                    $object = new stdClass();
                    $object->id = substr($key, 13);
                    $csvFile = $file['tmp_name'][0];
                    if (!empty($csvFile) && Joomla\CMS\Filesystem\File::getExt($file['name'][0]) == 'csv') {
                        $handle = @fopen($csvFile, 'r');
                        $csvData = [];
                        while (($data = fgetcsv($handle, 1000)) !== false) {
                            $csvData[] = $data;
                        }

                        fclose($handle);
                        $object->value = $csvData;
                    } else {
                        $object->value = json_decode(K2Request::getVar('K2CSV_'.$object->id));
                        if (K2Request::getBool('K2ResetCSV_'.$object->id)) {
                            $object->value = null;
                        }
                    }

                    $objects[] = $object;
                }
            }

            $row->extra_fields = json_encode($objects);

            require_once JPATH_COMPONENT_ADMINISTRATOR.'/models/extrafield.php';
            $extraFieldModel = K2Model::getInstance('ExtraField', 'K2Model');
            $row->extra_fields_search = '';
            foreach ($objects as $object) {
                $row->extra_fields_search .= $extraFieldModel->getSearchValue($object->id, $object->value);
                $row->extra_fields_search .= ' ';
            }
        }

        // Attachments
        $path = $params->get('attachmentsFolder', null);
        $savepath = is_null($path) ? JPATH_ROOT.'/media/k2/attachments' : $path;

        $attPost = K2Request::getVar('attachment', null, 'POST', 'array');
        $attFiles = K2Request::getVar('attachment', null, 'FILES', 'array');

        if (is_array($attPost) && count($attPost)) {
            foreach ($attPost as $key => $attachment) { /* Use the POST array's key as reference */
                if (!empty($attachment['existing'])) {
                    $src = JPATH_SITE.'/'.Joomla\CMS\Filesystem\Path::clean($attachment['existing']);
                    $filename = basename($src);
                    $dest = $savepath.'/'.$filename;

                    if (Joomla\CMS\Filesystem\File::exists($dest)) {
                        $existingFileName = Joomla\CMS\Filesystem\File::getName($dest);
                        $ext = Joomla\CMS\Filesystem\File::getExt($existingFileName);
                        $basename = Joomla\CMS\Filesystem\File::stripExt($existingFileName);
                        $newFilename = $basename.'_'.time().'.'.$ext;
                        $filename = $newFilename;
                        $dest = $savepath.'/'.$newFilename;
                    }

                    Joomla\CMS\Filesystem\File::copy($src, $dest);

                    $attachmentToSave = Joomla\CMS\Table\Table::getInstance('K2Attachment', 'Table');
                    $attachmentToSave->itemID = $row->id;
                    $attachmentToSave->filename = $filename;
                    $attachmentToSave->title = (empty($attachment['title'])) ? $filename : $attachment['title'];
                    $attachmentToSave->titleAttribute = (empty($attachment['title_attribute'])) ? $filename : $attachment['title_attribute'];
                    $attachmentToSave->store();
                } else {
                    try {
                        $handle = new Verot\Upload\Upload($attFiles['tmp_name'][$key]['upload']);
                        $filename = $attFiles['name'][$key]['upload'];
                        if ($handle->uploaded) {
                            $handle->file_auto_rename = true;
                            $handle->file_new_name_body = Joomla\CMS\Filesystem\File::stripExt($filename);
                            $handle->file_new_name_ext = Joomla\CMS\Filesystem\File::getExt($filename);
                            $handle->file_safe_name = true;
                            $handle->forbidden = [
                                'application/java-archive',
                                'application/x-httpd-php',
                                'application/x-sh',
                            ];

                            $handle->process($savepath);

                            if ($handle->processed) {
                                $dstName = $handle->file_dst_name;

                                $attachmentToSave = Joomla\CMS\Table\Table::getInstance('K2Attachment', 'Table');
                                $attachmentToSave->itemID = $row->id;
                                $attachmentToSave->filename = $dstName;
                                $attachmentToSave->title = (empty($attachment['title'])) ? $filename : $attachment['title'];
                                $attachmentToSave->titleAttribute = (empty($attachment['title_attribute'])) ? $filename : $attachment['title_attribute'];
                                $attachmentToSave->store();

                                $handle->clean();
                            } else {
                                throw new RuntimeException($handle->error);
                            }
                        }
                    } catch (Exception $e) {
                        $app->enqueueMessage($e->getMessage(), 'error');
                        $app->redirect('index.php?option=com_k2&view=items');
                    }
                }
            }
        }

        // Check publishing permissions in frontend editing
        if ($front) {
            $newPublishedState = $row->published;
            $row->published = 0;

            // "Allow editing of already published items" permission check
            if (!$isNew && K2HelperPermissions::canEditPublished($row->catid)) {
                $row->published = $published;
            }

            // "Publish items" permission check
            if (K2HelperPermissions::canPublishItem($row->catid)) {
                $row->published = $newPublishedState;
            }

            if (!K2HelperPermissions::canEditPublished($row->catid) && !K2HelperPermissions::canPublishItem($row->catid) && $newPublishedState) {
                $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_YOU_DONT_HAVE_THE_PERMISSION_TO_PUBLISH_ITEMS'), 'notice');
            }
        }

        $query = 'UPDATE #__k2_items SET
            image_caption = '.$db->Quote($row->image_caption).',
            image_credits = '.$db->Quote($row->image_credits).',
            video_caption = '.$db->Quote($row->video_caption).',
            video_credits = '.$db->Quote($row->video_credits).',
            video = '.$db->Quote($row->video).',
            gallery = '.$db->Quote($row->gallery);
        if ($params->get('showExtraFieldsTab') || $app->isClient('administrator')) {
            $query .= ', extra_fields = '.$db->Quote($row->extra_fields).', extra_fields_search = '.$db->Quote($row->extra_fields_search);
        }

        $query .= ', published = '.$db->Quote($row->published).' WHERE id = '.$row->id;

        $db->setQuery($query);

        if (!$db->query()) {
            $app->enqueueMessage($db->getErrorMsg(), 'error');
            $app->redirect('index.php?option=com_k2&view=items');
        }

        $row->checkin();

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();

        // Trigger K2 plugins
        $dispatcher->trigger('onAfterK2Save', [&$row, $isNew]);

        // Trigger content & finder plugins after the save event
        if (K2_JVERSION != '15') {
            $dispatcher->trigger('onContentAfterSave', ['com_k2.item', &$row, $isNew]);
        } else {
            $dispatcher->trigger('onAfterContentSave', [&$row, $isNew]);
        }

        $results = $dispatcher->trigger('onFinderAfterSave', ['com_k2.item', $row, $isNew]);

        switch (K2Request::getCmd('task')) {
            case 'apply':
                $msg = Joomla\CMS\Language\Text::_('K2_CHANGES_TO_ITEM_SAVED');
                $link = 'index.php?option=com_k2&view=item&cid='.$row->id;
                break;
            case 'saveAndNew':
                $msg = Joomla\CMS\Language\Text::_('K2_ITEM_SAVED');
                $link = 'index.php?option=com_k2&view=item';
                break;
            case 'save':
            default:
                $msg = Joomla\CMS\Language\Text::_('K2_ITEM_SAVED');
                if ($front) {
                    $link = 'index.php?option=com_k2&view=item&task=edit&cid='.$row->id.'&tmpl=component&Itemid='.K2Request::getInt('Itemid');
                } else {
                    $link = 'index.php?option=com_k2&view=items';
                }

                break;
        }

        $app->enqueueMessage($msg);
        $app->redirect($link);

        return null;
    }

    public function cancel()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $cid = K2Request::getInt('id');
        if ($cid) {
            $row = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
            $row->load($cid);
            $row->checkin();
        } else {
            // Cleanup SIGPro
            $sigProFolder = K2Request::getCmd('sigProFolder');
            if ($sigProFolder && !is_numeric($sigProFolder) && Joomla\CMS\Filesystem\Folder::exists(JPATH_SITE.'/media/k2/galleries/'.$sigProFolder)) {
                Joomla\CMS\Filesystem\Folder::delete(JPATH_SITE.'/media/k2/galleries/'.$sigProFolder);
            }
        }

        $app->redirect('index.php?option=com_k2&view=items');
    }

    public function getVideoProviders()
    {
        jimport('joomla.filesystem.file');

        if (K2_JVERSION != '15') {
            $file = JPATH_PLUGINS.'/content/jw_allvideos/jw_allvideos/includes/sources.php';
        } else {
            $file = JPATH_PLUGINS.'/content/jw_allvideos/includes/sources.php';
        }

        $providers = [];

        if (Joomla\CMS\Filesystem\File::exists($file)) {
            require $file;
            if (!empty($tagReplace) && is_array($tagReplace)) {
                foreach ($tagReplace as $name => $embed) {
                    if (str_contains($embed, '<iframe') || str_contains($embed, '<script')) {
                        $providers[] = $name;
                    }
                }
            }
        }

        return $providers;
    }

    public function download()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $user = Joomla\CMS\Factory::getUser();
        jimport('joomla.filesystem.file');
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        $id = K2Request::getInt('id');

        // Plugin Events
        Joomla\CMS\Plugin\PluginHelper::importPlugin('k2');
        $dispatcher = JDispatcher::getInstance();

        $attachment = Joomla\CMS\Table\Table::getInstance('K2Attachment', 'Table');
        if ($app->isClient('site')) {
            $token = K2Request::getVar('id');
            $check = JString::substr($token, JString::strpos($token, '_') + 1);
            $hash = version_compare(JVERSION, '3.0', 'ge') ? JApplication::getHash($id) : Joomla\CMS\Utility\Utility::getHash($id);
            if ($check != $hash) {
                JError::raiseError(404, Joomla\CMS\Language\Text::_('K2_NOT_FOUND'));
            }
        }

        $attachment->load($id);

        // Frontend Editing: Ensure the user has access to the item
        if ($app->isClient('site')) {
            $item = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
            $item->load($attachment->itemID);
            $category = Joomla\CMS\Table\Table::getInstance('K2Category', 'Table');
            $category->load($item->catid);
            if (!$item->id || !$category->id) {
                JError::raiseError(404, Joomla\CMS\Language\Text::_('K2_NOT_FOUND'));
            }

            if (K2_JVERSION == '15' && ($item->access > $user->get('aid', 0) || $category->access > $user->get('aid', 0))) {
                JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
            }

            if (K2_JVERSION != '15' && (!in_array($category->access, $user->getAuthorisedViewLevels()) || !in_array($item->access, $user->getAuthorisedViewLevels()))) {
                JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
            }
        }

        // Trigger K2 plugins
        $dispatcher->trigger('onK2BeforeDownload', [&$attachment, &$params]);

        $path = $params->get('attachmentsFolder', null);
        $savepath = is_null($path) ? JPATH_ROOT.'/media/k2/attachments' : $path;

        $file = $savepath.'/'.$attachment->filename;

        if (Joomla\CMS\Filesystem\File::exists($file)) {
            // Trigger K2 plugins
            $dispatcher->trigger('onK2AfterDownload', [&$attachment, &$params]);

            if ($app->isClient('site')) {
                $attachment->hit();
            }

            $len = filesize($file);
            $filename = basename($file);
            ob_end_clean();
            JResponse::clearHeaders();
            JResponse::setHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0', true);
            JResponse::setHeader('Content-Disposition', 'attachment; filename="'.$filename.'";', true);
            JResponse::setHeader('Content-Length', $len, true);
            JResponse::setHeader('Content-Transfer-Encoding', 'binary', true);
            JResponse::setHeader('Content-Type', 'application/octet-stream', true);
            JResponse::setHeader('Expires', '0', true);
            JResponse::setHeader('Pragma', 'public', true);
            JResponse::sendHeaders();
            readfile($file);
        } else {
            echo Joomla\CMS\Language\Text::_('K2_FILE_DOES_NOT_EXIST');
        }

        $app->close();
    }

    public function getAttachments($itemID)
    {
        $db = Joomla\CMS\Factory::getDbo();
        $db->setQuery('SELECT * FROM #__k2_attachments WHERE itemID='.(int) $itemID);

        $rows = $db->loadObjectList();
        foreach ($rows as $row) {
            $hash = version_compare(JVERSION, '3.0', 'ge') ? JApplication::getHash($row->id) : Joomla\CMS\Utility\Utility::getHash($row->id);
            $row->link = Joomla\CMS\Router\Route::_('index.php?option=com_k2&view=item&task=download&id='.$row->id.'_'.$hash);
        }

        return $rows;
    }

    public function deleteAttachment()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        jimport('joomla.filesystem.file');
        $id = K2Request::getInt('id');
        $itemID = K2Request::getInt('cid');

        // Plugin Events
        Joomla\CMS\Plugin\PluginHelper::importPlugin('k2');
        $dispatcher = JDispatcher::getInstance();

        $db = Joomla\CMS\Factory::getDbo();
        $db->setQuery(sprintf('SELECT COUNT(*) FROM #__k2_attachments WHERE itemID=%s AND id=%s', $itemID, $id));

        $result = $db->loadResult();

        if (!$result) {
            $app->close();
        }

        $row = Joomla\CMS\Table\Table::getInstance('K2Attachment', 'Table');
        $row->load($id);

        $path = $params->get('attachmentsFolder', null);
        $savepath = is_null($path) ? JPATH_ROOT.'/media/k2/attachments' : $path;

        if (Joomla\CMS\Filesystem\File::exists($savepath.'/'.$row->filename)) {
            Joomla\CMS\Filesystem\File::delete($savepath.'/'.$row->filename);
        }

        $row->delete($id);

        // Trigger K2 plugins
        $result = $dispatcher->trigger('onAfterK2DeleteAttachment', [$id, $savepath]);

        $app->close();
    }

    public function getAvailableTags($itemID = null)
    {
        $db = Joomla\CMS\Factory::getDbo();
        $query = 'SELECT * FROM #__k2_tags as tags';
        if (!is_null($itemID)) {
            $query .= ' WHERE tags.id NOT IN (SELECT tagID FROM #__k2_tags_xref WHERE itemID='.(int) $itemID.')';
        }

        $db->setQuery($query);
        $rows = $db->loadObjectList();

        return $rows;
    }

    public function getCurrentTags($itemID)
    {
        $db = Joomla\CMS\Factory::getDbo();
        $itemID = (int) $itemID;
        $db->setQuery('SELECT tags.* FROM #__k2_tags AS tags JOIN #__k2_tags_xref AS xref ON tags.id = xref.tagID WHERE xref.itemID = '.(int) $itemID.' ORDER BY xref.id ASC');
        $rows = $db->loadObjectList();

        return $rows;
    }

    public function resetHits()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $id = K2Request::getInt('id');
        $db = Joomla\CMS\Factory::getDbo();
        $db->setQuery('UPDATE #__k2_items SET hits=0 WHERE id='.$id);
        $db->execute();
        if ($app->isClient('administrator')) {
            $url = 'index.php?option=com_k2&view=item&cid='.$id;
        } else {
            $url = 'index.php?option=com_k2&view=item&task=edit&cid='.$id.'&tmpl=component';
        }

        $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_SUCCESSFULLY_RESET_ITEM_HITS'));
        $app->redirect($url);
    }

    public function resetRating()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $id = K2Request::getInt('id');
        $db = Joomla\CMS\Factory::getDbo();
        $db->setQuery('DELETE FROM #__k2_rating WHERE itemID='.$id);
        $db->execute();
        if ($app->isClient('administrator')) {
            $url = 'index.php?option=com_k2&view=item&cid='.$id;
        } else {
            $url = 'index.php?option=com_k2&view=item&task=edit&cid='.$id.'&tmpl=component';
        }

        $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_SUCCESSFULLY_RESET_ITEM_RATING'));
        $app->redirect($url);
    }

    public function getRating()
    {
        $id = K2Request::getInt('cid');
        $db = Joomla\CMS\Factory::getDbo();
        $db->setQuery('SELECT * FROM #__k2_rating WHERE itemID='.$id, 0, 1);

        $row = $db->loadObject();

        return $row;
    }

    public function checkSIG()
    {
        $app = Joomla\CMS\Factory::getApplication();
        if (K2_JVERSION != '15') {
            $check = JPATH_PLUGINS.'/content/jw_sigpro/jw_sigpro.php';
        } else {
            $check = JPATH_PLUGINS.'/content/jw_sigpro.php';
        }

        return (bool) (Joomla\CMS\Filesystem\File::exists($check));
    }

    public function checkAllVideos()
    {
        $app = Joomla\CMS\Factory::getApplication();
        if (K2_JVERSION != '15') {
            $check = JPATH_PLUGINS.'/content/jw_allvideos/jw_allvideos.php';
        } else {
            $check = JPATH_PLUGINS.'/content/jw_allvideos.php';
        }

        return (bool) (Joomla\CMS\Filesystem\File::exists($check));
    }

    public function cleanText($text)
    {
        if (version_compare(JVERSION, '2.5.0', 'ge')) {
            $text = Joomla\CMS\Component\ComponentHelper::filterText($text);
        } elseif (version_compare(JVERSION, '2.5.0', 'lt') && version_compare(JVERSION, '1.6.0', 'ge')) {
            JLoader::register('ContentHelper', JPATH_ADMINISTRATOR.'/components/com_content/helpers/content.php');
            $text = ContentHelper::filterText($text);
        } else {
            $config = Joomla\CMS\Component\ComponentHelper::getParams('com_content');
            $user = Joomla\CMS\Factory::getUser();
            $gid = $user->get('gid');
            $filterGroups = $config->get('filter_groups');

            // Convert to array if one group is selected
            if ((!is_array($filterGroups) && (int) $filterGroups > 0)) {
                $filterGroups = [$filterGroups];
            }

            if (is_array($filterGroups) && in_array($gid, $filterGroups)) {
                $filterType = $config->get('filter_type');
                $filterTags = preg_split('#[,\s]+#', trim($config->get('filter_tags')));
                $filterAttrs = preg_split('#[,\s]+#', trim($config->get('filter_attritbutes')));
                switch ($filterType) {
                    case 'NH':
                        $filter = new JFilterInput();
                        break;
                    case 'WL':
                        $filter = new JFilterInput($filterTags, $filterAttrs, 0, 0, 0);
                        break;
                    case 'BL':
                    default:
                        $filter = new JFilterInput($filterTags, $filterAttrs, 1, 1);
                        break;
                }

                $text = $filter->clean($text);
            } elseif (empty($filterGroups) && $gid != '25') {
                // No default filtering for super admin (gid=25)
                $filter = new JFilterInput([], [], 1, 1);
                $text = $filter->clean($text);
            }
        }

        return $text;
    }
}
