<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

jimport('joomla.application.component.model');

Joomla\CMS\Table\Table::addIncludePath(JPATH_COMPONENT.'/tables');

class K2ModelComments extends K2Model
{
    private $getTotal;

    public function getData()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        $option = K2Request::getCmd('option');
        $view = K2Request::getCmd('view');
        $db = Joomla\CMS\Factory::getDbo();
        $limit = $app->getUserStateFromRequest('global.list.limit', 'limit', $app->getCfg('list_limit'), 'int');
        $limitstart = $app->getUserStateFromRequest($option.$view.'.limitstart', 'limitstart', 0, 'int');
        $filter_order = $app->getUserStateFromRequest($option.$view.'filter_order', 'filter_order', 'c.id', 'cmd');
        $filter_order_Dir = $app->getUserStateFromRequest($option.$view.'filter_order_Dir', 'filter_order_Dir', 'DESC', 'word');
        $filter_state = $app->getUserStateFromRequest($option.$view.'filter_state', 'filter_state', -1, 'int');
        $filter_category = $app->getUserStateFromRequest($option.$view.'filter_category', 'filter_category', 0, 'int');
        $filter_author = $app->getUserStateFromRequest($option.$view.'filter_author', 'filter_author', 0, 'int');
        $search = $app->getUserStateFromRequest($option.$view.'search', 'search', '', 'string');
        $search = JString::strtolower($search);
        $search = trim(preg_replace('/[^\p{L}\p{N}\s\"\.\@\-_]/u', '', $search));

        $queryStart = '/* Backend / K2 / Comments */ SELECT c.*, i.title , i.catid, i.alias AS itemAlias, i.created_by, cat.alias AS catAlias, cat.name as catName';

        $query = ' FROM #__k2_comments AS c
			LEFT JOIN #__k2_items AS i ON c.itemID = i.id
			LEFT JOIN #__k2_categories AS cat ON cat.id = i.catid
			LEFT JOIN #__k2_users AS u ON c.userID = u.userID
			WHERE c.id > 0';

        if ($filter_state > -1) {
            $query .= ' AND c.published = '.$filter_state;
        }

        if ($filter_category) {
            $query .= ' AND i.catid = '.$filter_category;
        }

        if ($filter_author) {
            $query .= ' AND i.created_by = '.$filter_author;
        }

        if ($search !== '' && $search !== '0') {
            // Detect exact search phrase using double quotes in search string
            $exact = str_starts_with($search, '"') && str_ends_with($search, '"');

            // Now completely strip double quotes
            $search = trim(str_replace('"', '', $search));

            // Escape remaining string
            $escaped = K2_JVERSION == '15' ? $db->getEscaped($search, true) : $db->escape($search, true);

            // Full phrase or set of words
            if (str_contains($escaped, ' ') && !$exact) {
                $escaped = explode(' ', $escaped);
                $quoted = [];
                foreach ($escaped as $key => $escapedWord) {
                    $quoted[] = $db->Quote('%'.$escapedWord.'%', false);
                }

                if ($params->get('adminSearch') == 'full') {
                    $searchPerTerm = [];
                    $query .= ' AND (';
                    foreach ($quoted as $quotedWord) {
                        $query .= '
							LOWER(c.commentText) LIKE '.$quotedWord.' OR
							LOWER(c.userName) LIKE '.$quotedWord.' OR
							LOWER(c.commentEmail) LIKE '.$quotedWord.' OR
							LOWER(c.commentURL) LIKE '.$quotedWord.' OR
							LOWER(i.title) LIKE '.$quotedWord.' OR
							LOWER(u.userName) LIKE '.$quotedWord.' OR
							LOWER(u.ip) LIKE '.$quotedWord.'
 						';
                    }

                    $query .= implode(' OR ', $searchPerTerm);
                    $query .= ')';
                } else {
                    foreach ($quoted as $quotedWord) {
                        $query .= ' AND LOWER(c.commentText) LIKE '.$quotedWord;
                    }
                }
            }
            // Single word or exact phrase to search for (wrapped in double quotes in the search block)
            else {
                $quoted = $db->Quote('%'.$escaped.'%', false);
                if ($params->get('adminSearch') == 'full') {
                    $query .= ' AND (
						LOWER(c.commentText) LIKE '.$quoted.' OR
						LOWER(c.userName) LIKE '.$quoted.' OR
						LOWER(c.commentEmail) LIKE '.$quoted.' OR
						LOWER(c.commentURL) LIKE '.$quoted.' OR
						LOWER(i.title) LIKE '.$quoted.' OR
						LOWER(u.userName) LIKE '.$quoted.' OR
						LOWER(u.ip) LIKE '.$quoted.'
					)';
                } else {
                    $query .= ' AND LOWER(c.commentText) LIKE '.$quoted;
                }
            }
        }

        if (!$filter_order) {
            $filter_order = 'c.commentDate';
        }

        $queryEnd = sprintf(' ORDER BY %s %s', $filter_order, $filter_order_Dir);

        // --- Final query ---
        $combinedQuery = $queryStart.$query.$queryEnd;

        $db->setQuery($combinedQuery, $limitstart, $limit);
        $rows = $db->loadObjectList();

        // --- Row counter ---
        if (count($rows) > 0) {
            $countQuery = '/* Backend / K2 / Comments Count */ SELECT COUNT(*)'.$query;
            $db->setQuery($countQuery);
            $this->getTotal = $db->loadResult();
        }

        return $rows;
    }

    public function getTotal()
    {
        return $this->getTotal;
    }

    public function publish()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $user = Joomla\CMS\Factory::getUser();
        $cid = K2Request::getVar('cid');
        if (count($cid) === 0) {
            $cid[] = K2Request::getInt('commentID');
        }

        foreach ($cid as $id) {
            $row = Joomla\CMS\Table\Table::getInstance('K2Comment', 'Table');
            $row->load($id);
            if ($app->isClient('site')) {
                $item = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
                $item->load($row->itemID);
                if ($item->created_by != $user->id) {
                    JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
                    $app->close();
                }
            }

            $row->published = 1;
            $row->store();
        }

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();
        if (K2Request::getCmd('format') == 'raw') {
            echo 'true';
            $app->close();
        }

        if (K2Request::getCmd('context') == 'modalselector') {
            $app->redirect('index.php?option=com_k2&view=comments&tmpl=component&context=modalselector');
        } else {
            $app->redirect('index.php?option=com_k2&view=comments');
        }
    }

    public function unpublish()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $user = Joomla\CMS\Factory::getUser();
        $cid = K2Request::getVar('cid');
        foreach ($cid as $id) {
            $row = Joomla\CMS\Table\Table::getInstance('K2Comment', 'Table');
            $row->load($id);
            if ($app->isClient('site')) {
                $item = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
                $item->load($row->itemID);
                if ($item->created_by != $user->id) {
                    JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
                    $app->close();
                }
            }

            $row->published = 0;
            $row->store();
        }

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();
        if (K2Request::getCmd('context') == 'modalselector') {
            $app->redirect('index.php?option=com_k2&view=comments&tmpl=component&context=modalselector');
        } else {
            $app->redirect('index.php?option=com_k2&view=comments');
        }
    }

    public function remove()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $user = Joomla\CMS\Factory::getUser();
        $db = Joomla\CMS\Factory::getDbo();
        $cid = K2Request::getVar('cid');
        if (count($cid) === 0) {
            $cid[] = K2Request::getInt('commentID');
        }

        foreach ($cid as $id) {
            $row = Joomla\CMS\Table\Table::getInstance('K2Comment', 'Table');
            $row->load($id);
            if ($app->isClient('site')) {
                $item = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
                $item->load($row->itemID);
                if ($item->created_by != $user->id) {
                    JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
                    $app->close();
                }
            }

            $row->delete($id);
        }

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();
        if (K2Request::getCmd('format') == 'raw') {
            echo 'true';
            $app->close();
        }

        $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_DELETE_COMPLETED'));
        if (K2Request::getCmd('context') == 'modalselector') {
            $app->redirect('index.php?option=com_k2&view=comments&tmpl=component&context=modalselector');
        } else {
            $app->redirect('index.php?option=com_k2&view=comments');
        }
    }

    public function deleteUnpublished()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $db = Joomla\CMS\Factory::getDbo();
        $user = Joomla\CMS\Factory::getUser();
        $userID = $user->id;
        if ($app->isClient('site')) {
            $query = "SELECT c.id FROM #__k2_comments AS c
			LEFT JOIN #__k2_items AS i ON c.itemID=i.id
			WHERE i.created_by = {$userID} AND c.published=0";
            $db->setQuery($query);
            $ids = K2_JVERSION == '30' ? $db->loadColumn() : $db->loadResultArray();
            if (count($ids) > 0) {
                $query = 'DELETE FROM #__k2_comments WHERE id IN('.implode(',', $ids).')';
                $db->setQuery($query);
                $db->execute();
            }
        } else {
            $query = 'DELETE FROM #__k2_comments WHERE published=0';
            $db->setQuery($query);
            $db->execute();
        }

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();

        $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_DELETE_COMPLETED'));
        if (K2Request::getCmd('context') == 'modalselector') {
            $app->redirect('index.php?option=com_k2&view=comments&tmpl=component&context=modalselector');
        } else {
            $app->redirect('index.php?option=com_k2&view=comments');
        }
    }

    public function save()
    {
        $app = Joomla\CMS\Factory::getApplication();
        $user = Joomla\CMS\Factory::getUser();
        $db = Joomla\CMS\Factory::getDbo();
        $id = K2Request::getInt('commentID');
        $item = Joomla\CMS\Table\Table::getInstance('K2Item', 'Table');
        $row = Joomla\CMS\Table\Table::getInstance('K2Comment', 'Table');
        $row->load($id);
        if ($app->isClient('site')) {
            $item->load($row->itemID);
            if ($item->created_by != $user->id) {
                JError::raiseError(403, Joomla\CMS\Language\Text::_('K2_ALERTNOTAUTH'));
            }
        }

        $row->commentText = K2Request::getVar('commentText', '', 'default', 'string', 4);
        $row->store();

        $cache = Joomla\CMS\Factory::getCache('com_k2');
        $cache->clean();

        $response = new stdClass();
        $response->comment = $row->commentText;
        $response->message = Joomla\CMS\Language\Text::_('K2_COMMENT_SAVED');
        echo json_encode($response);
        $app->close();
    }

    public function report()
    {
        $id = $this->getState('id');
        $name = JString::trim($this->getState('name'));
        $reportReason = JString::trim($this->getState('reportReason'));
        $params = K2HelperUtilities::getParams('com_k2');
        $user = Joomla\CMS\Factory::getUser();
        $row = Joomla\CMS\Table\Table::getInstance('K2Comment', 'Table');
        $row->load($id);
        if (!$row->published) {
            $this->setError(Joomla\CMS\Language\Text::_('K2_COMMENT_NOT_FOUND'));

            return false;
        }

        if (empty($name)) {
            $this->setError(Joomla\CMS\Language\Text::_('K2_PLEASE_TYPE_YOUR_NAME'));

            return false;
        }

        if (empty($reportReason)) {
            $this->setError(Joomla\CMS\Language\Text::_('K2_PLEASE_TYPE_THE_REPORT_REASON'));

            return false;
        }

        if (($params->get('antispam') == 'recaptcha' || $params->get('antispam') == 'both') && $user->guest) {
            require_once JPATH_SITE.'/components/com_k2/helpers/utilities.php';
            if (!K2HelperUtilities::verifyRecaptcha()) {
                $this->setError(Joomla\CMS\Language\Text::_('K2_COULD_NOT_VERIFY_THAT_YOU_ARE_NOT_A_ROBOT'));

                return false;
            }
        }

        $app = Joomla\CMS\Factory::getApplication();
        $mail = Joomla\CMS\Factory::getMailer();
        $senderEmail = $app->getCfg('mailfrom');
        $senderName = $app->getCfg('fromname');

        $mail->setSender([$senderEmail, $senderName]);
        $mail->setSubject(Joomla\CMS\Language\Text::_('K2_COMMENT_REPORT'));
        $mail->IsHTML(true);

        switch (substr(strtoupper(PHP_OS), 0, 3)) {
            case 'WIN':
                $mail->LE = "\r\n";
                break;
            case 'MAC':
            case 'DAR':
                $mail->LE = "\r";
                // no break
            default:
                break;
        }

        // K2 embedded email template (to do: move to separate HTML template/override)
        $body = '
        <strong>'.Joomla\CMS\Language\Text::_('K2_NAME').'</strong>: '.$name.' <br/>
        <strong>'.Joomla\CMS\Language\Text::_('K2_REPORT_REASON').'</strong>: '.$reportReason.' <br/>
        <strong>'.Joomla\CMS\Language\Text::_('K2_COMMENT').'</strong>: '.nl2br($row->commentText).' <br/>
        ';

        $mail->setBody($body);
        $mail->ClearAddresses();
        $mail->AddAddress($params->get('commentsReportRecipient', $app->getCfg('mailfrom')));
        $mail->Send();

        return true;
    }
}
