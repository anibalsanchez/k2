<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

require_once JPATH_ADMINISTRATOR.'/components/com_k2/tables/table.php';

class TableK2Category extends K2Table
{
    public $_tbl_key;

    public $_tbl;

    public $id = null;

    public $name = null;

    public $alias = null;

    public $description = null;

    public $parent = null;

    public $extraFieldsGroup = null;

    public $published = null;

    public $image = null;

    public $access = null;

    public $ordering = null;

    public $params = null;

    public $trash = null;

    public $plugins = null;

    public $language = null;

    public function __construct(&$db)
    {
        parent::__construct('#__k2_categories', 'id', $db);
    }

    public function load($oid = null, $reset = false)
    {
        static $K2CategoriesInstances = [];
        if (isset($K2CategoriesInstances[$oid])) {
            return $this->bind($K2CategoriesInstances[$oid]);
        }

        $k = $this->_tbl_key;

        if ($oid !== null) {
            $this->$k = $oid;
        }

        $oid = $this->$k;

        if ($oid === null) {
            return false;
        }

        $this->reset();

        $db = $this->getDBO();

        $query = 'SELECT * FROM '.$this->_tbl.' WHERE '.$this->_tbl_key.' = '.$db->Quote($oid);
        $db->setQuery($query);
        $result = $db->loadAssoc();
        if ($result) {
            $K2CategoriesInstances[$oid] = $result;

            return $this->bind($K2CategoriesInstances[$oid]);
        }

        $this->setError($db->getErrorMsg());

        return false;
    }

    public function check()
    {
        jimport('joomla.filter.output');
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        $this->name = JString::trim($this->name);
        if ($this->name == '') {
            $this->setError(Joomla\CMS\Language\Text::_('K2_CATEGORY_MUST_HAVE_A_NAME'));

            return false;
        }

        if (empty($this->alias)) {
            $this->alias = $this->name;
        }

        /* Offload the alias processing block to a simplified external function/method call */
        if (K2_JVERSION == '15') {
            if (Joomla\CMS\Plugin\PluginHelper::isEnabled('system', 'unicodeslug') || Joomla\CMS\Plugin\PluginHelper::isEnabled('system', 'jw_unicodeSlugsExtended')) {
                $this->alias = Joomla\CMS\Filter\OutputFilter::stringURLSafe($this->alias);
            } else {
                mb_internal_encoding('UTF-8');
                mb_regex_encoding('UTF-8');
                $this->alias = trim(mb_strtolower($this->alias));
                $this->alias = str_replace('-', ' ', $this->alias);
                $this->alias = str_replace('/', '-', $this->alias);
                $this->alias = mb_ereg_replace('[[:space:]]+', ' ', $this->alias);
                $this->alias = trim(str_replace(' ', '-', $this->alias));
                $this->alias = str_replace('.', '', $this->alias);
                $this->alias = str_replace('"', '', $this->alias);
                $this->alias = str_replace("'", '', $this->alias);
                $stripthese = ',|~|!|@|%|^|(|)|<|>|:|;|{|}|[|]|&|`|â€ž|â€¹|â€™|â€˜|â€œ|â€�|â€¢|â€º|Â«|Â´|Â»|Â°|«|»|…';
                $strips = explode('|', $stripthese);
                foreach ($strips as $strip) {
                    $this->alias = str_replace($strip, '', $this->alias);
                }

                if (trim(str_replace('-', '', $this->alias)) === '') {
                    $datenow = Joomla\CMS\Factory::getDate();
                    $this->alias = $datenow->toFormat('%Y-%m-%d-%H-%M-%S');
                }

                $this->alias = trim($this->alias, '-.');
            }
        } elseif (Joomla\CMS\Factory::getConfig()->get('unicodeslugs') == 1) {
            $this->alias = Joomla\CMS\Filter\OutputFilter::stringURLUnicodeSlug($this->alias);
        } else {
            // Detect the site language we will transliterate
            if ($this->language == '*') {
                $langParams = Joomla\CMS\Component\ComponentHelper::getParams('com_languages');
                $languageTag = $langParams->get('site');
            } else {
                $languageTag = $this->language;
            }

            $language = Joomla\CMS\Language\Language::getInstance($languageTag);
            $this->alias = $language->transliterate($this->alias);
            $this->alias = Joomla\CMS\Filter\OutputFilter::stringURLSafe($this->alias);
            if (trim(str_replace('-', '', $this->alias)) === '') {
                $this->alias = Joomla\CMS\Factory::getDate()->format('Y-m-d-H-i-s');
            }
        }

        if (K2_JVERSION == '15' || $params->get('enforceSEFReplacements')) {
            $SEFReplacements = [];
            $items = explode(',', $params->get('SEFReplacements'));
            foreach ($items as $item) {
                if ($item !== '' && $item !== '0') {
                    @[$src, $dst] = explode('|', trim($item));
                    $SEFReplacements[trim($src)] = trim($dst);
                }
            }

            foreach ($SEFReplacements as $key => $value) {
                $this->alias = str_replace($key, $value, $this->alias);
            }

            $this->alias = trim($this->alias, '-.');
        }

        if (K2_JVERSION == '15' && trim(str_replace('-', '', $this->alias)) === '') {
            $datenow = Joomla\CMS\Factory::getDate();
            $this->alias = $datenow->toFormat('%Y-%m-%d-%H-%M-%S');
        }

        // Check if alias already exists. If so warn the user
        $params = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
        if ($params->get('k2Sef') && !$params->get('k2SefInsertCatId')) {
            $db = Joomla\CMS\Factory::getDbo();
            $db->setQuery('SELECT id FROM #__k2_categories WHERE alias = '.$db->quote($this->alias).' AND id != '.(int) $this->id);
            $result = count($db->loadObjectList());
            if ($result > 0) {
                $this->alias .= '-'.((int) $result + 1);
                $app = Joomla\CMS\Factory::getApplication();
                $app->enqueueMessage(Joomla\CMS\Language\Text::_('K2_WARNING_DUPLICATE_TITLE_ALIAS_DETECTED'), 'notice');
            }
        }

        return true;
    }

    public function bind($array, $ignore = '')
    {
        if (array_key_exists('params', $array) && is_array($array['params'])) {
            $registry = new JRegistry();
            $registry->loadArray($array['params']);
            $array['params'] = $registry->toString();
        }

        if (array_key_exists('plugins', $array) && is_array($array['plugins'])) {
            $registry = new JRegistry();
            $registry->loadArray($array['plugins']);
            $array['plugins'] = $registry->toString();
        }

        return parent::bind($array, $ignore);
    }
}
