<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

$user = Joomla\CMS\Factory::getUser();

if (K2_JVERSION != '15') {
    if (!$user->authorise('core.manage', 'com_k2')) {
        return;
    }

    $language = Joomla\CMS\Factory::getLanguage();
    $language->load('com_k2.dates', JPATH_ADMINISTRATOR);
    $user->gid = $user->authorise('core.admin', 'com_k2') ? 1000 : 1;
}

// JoomlaWorks reference parameters
$mod_name = 'mod_k2_quickicons';
$mod_copyrights_start = "\n\n<!-- JoomlaWorks \"K2 QuickIcons\" Module starts here -->\n";
$mod_copyrights_end = "\n<!-- JoomlaWorks \"K2 QuickIcons\" Module ends here -->\n\n";

// API
$app = Joomla\CMS\Factory::getApplication();
$document = Joomla\CMS\Factory::getDocument();
$user = Joomla\CMS\Factory::getUser();

// Module parameters
$moduleclass_sfx = $params->get('moduleclass_sfx', '');
$modCSSStyling = (int) $params->get('modCSSStyling', 1);
$modLogo = (int) $params->get('modLogo', 1);

// Component parameters
$componentParams = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');

// Load CSS & JS
K2HelperHTML::loadHeadIncludes(true, false, true, false);
if ($modCSSStyling !== 0) {
    $document->addStyleSheet(Joomla\CMS\Uri\Uri::base(true).'/modules/'.$mod_name.'/tmpl/css/style.css?v='.K2_CURRENT_VERSION);
}

// Output content with template
echo $mod_copyrights_start;
require Joomla\CMS\Helper\ModuleHelper::getLayoutPath($mod_name, 'default');
echo $mod_copyrights_end;
