<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

JLoader::register('K2HelperRoute', JPATH_SITE.'/components/com_k2/helpers/route.php');
JLoader::register('K2HelperUtilities', JPATH_SITE.'/components/com_k2/helpers/utilities.php');

class modK2UserHelper
{
    public static function getReturnURL($params, $type)
    {
        if ($itemid = $params->get($type)) {
            $app = Joomla\CMS\Factory::getApplication();
            $menu = $app->getMenu();
            $item = $menu->getItem($itemid);
            $url = K2_JVERSION != '15' ? 'index.php?Itemid='.$item->id : Joomla\CMS\Router\Route::_($item->link.'&Itemid='.$itemid, false);
        } else {
            // stay on the same page
            $uri = Joomla\CMS\Factory::getURI();
            $url = $uri->toString(['path', 'query', 'fragment']);
        }

        return base64_encode($url);
    }

    public static function getType()
    {
        $user = Joomla\CMS\Factory::getUser();

        return ($user->get('guest')) ? 'login' : 'logout';
    }

    public static function getProfile(&$params)
    {
        $user = Joomla\CMS\Factory::getUser();
        $db = Joomla\CMS\Factory::getDbo();
        $query = 'SELECT * FROM #__k2_users WHERE userID='.(int) $user->id;
        $db->setQuery($query, 0, 1);
        $profile = $db->loadObject();

        if ($profile) {
            if ($profile->image != '') {
                $profile->avatar = Joomla\CMS\Uri\Uri::root().'media/k2/users/'.$profile->image;
            }

            require_once JPATH_SITE.'/components/com_k2/helpers/permissions.php';
            if (K2Request::getCmd('option') != 'com_k2') {
                K2HelperPermissions::setPermissions();
            }

            if (K2HelperPermissions::canAddItem()) {
                $profile->addLink = Joomla\CMS\Router\Route::_('index.php?option=com_k2&view=item&task=add&tmpl=component&template=system&context=modalselector');
            }

            return $profile;
        }

        return null;
    }

    public static function countUserComments($userID)
    {
        $db = Joomla\CMS\Factory::getDbo();
        $query = 'SELECT COUNT(*) FROM #__k2_comments WHERE userID='.(int) $userID.' AND published=1';
        $db->setQuery($query);
        $result = $db->loadResult();

        return $result;
    }

    public static function getMenu($params)
    {
        $items = [];
        $children = [];
        if ($params->get('menu')) {
            $app = Joomla\CMS\Factory::getApplication();
            $menu = $app->getMenu();
            $items = $menu->getItems('menutype', $params->get('menu'));
        }

        foreach ($items as $item) {
            if (K2_JVERSION != '15') {
                $item->name = $item->title;
                $item->parent = $item->parent_id;
            }

            $index = $item->parent;
            $list = @$children[$index] ? $children[$index] : [];
            $list[] = $item;
            $children[$index] = $list;
        }

        if (K2_JVERSION != '15') {
            $items = Joomla\CMS\HTML\HTMLHelper::_('menu.treerecurse', 1, '', [], $children, 9999, 0, 0);
        } else {
            $items = Joomla\CMS\HTML\HTMLHelper::_('menu.treerecurse', 0, '', [], $children, 9999, 0, 0);
        }

        $links = [];
        foreach ($items as $item) {
            if (K2_JVERSION == '15') {
                $item->level = $item->sublevel;
                switch ($item->type) {
                    case 'separator':
                        continue 2;
                        break;
                    case 'url':
                        if ((str_starts_with($item->link, 'index.php?')) && (!str_contains($item->link, 'Itemid='))) {
                            $item->url = $item->link.'&amp;Itemid='.$item->id;
                        } else {
                            $item->url = $item->link;
                        }

                        break;
                    default:
                        $router = JSite::getRouter();
                        $item->url = $router->getMode() == JROUTER_MODE_SEF ? 'index.php?Itemid='.$item->id : $item->link.'&Itemid='.$item->id;
                        break;
                }

                $iParams = class_exists('JParameter') ? new JParameter($item->params) : new JRegistry($item->params);
                $iSecure = $iParams->def('secure', 0);
                if ($item->home == 1) {
                    $item->url = Joomla\CMS\Uri\Uri::base();
                } elseif (strcasecmp(substr($item->url, 0, 4), 'http') && (str_contains($item->link, 'index.php?'))) {
                    $item->url = Joomla\CMS\Router\Route::_($item->url, true, $iSecure);
                } else {
                    $item->url = str_replace('&', '&amp;', $item->url);
                }

                $item->route = $item->url;
            } else {
                $item->flink = $item->link;
                switch ($item->type) {
                    case 'separator':
                        continue 2;
                    case 'url':
                        if ((str_starts_with($item->link, 'index.php?')) && (!str_contains($item->link, 'Itemid='))) {
                            $item->flink = $item->link.'&Itemid='.$item->id;
                        }

                        break;
                    case 'alias':
                        $item->flink = 'index.php?Itemid='.$item->params->get('aliasoptions');
                        break;
                    default:
                        $router = JSite::getRouter();
                        if ($router->getMode() == JROUTER_MODE_SEF) {
                            $item->flink = 'index.php?Itemid='.$item->id;
                        } else {
                            $item->flink .= '&Itemid='.$item->id;
                        }

                        break;
                }

                if (strcasecmp(substr($item->flink, 0, 4), 'http') && (str_contains($item->flink, 'index.php?'))) {
                    $item->flink = Joomla\CMS\Router\Route::_($item->flink, true, $item->params->get('secure'));
                } else {
                    $item->flink = Joomla\CMS\Router\Route::_($item->flink);
                }

                $item->route = $item->flink;
            }

            $links[] = $item;
        }

        return $links;
    }
}
