<?php

/*
 * @package     k2-jx-ready
 *
 * @author      Extly, CB. <team@extly.com>
 * @copyright   Copyright (c)2025 Extly, CB. All rights reserved.
 * @license     https://www.gnu.org/licenses/gpl-3.0.html GNU/GPL
 *
 * @see         https://www.extly.com
 *
 * Based on K2 by JoomlaWorks Ltd. See: https://github.com/getk2/k2
 */

// no direct access
defined('_JEXEC') || die;

if (K2_JVERSION != '15') {
    $language = Joomla\CMS\Factory::getLanguage();
    $language->load('com_k2.dates', JPATH_ADMINISTRATOR, null, true);
}

require_once __DIR__.'/helper.php';

// Params
$moduleclass_sfx = $params->get('moduleclass_sfx', '');
$module_usage = $params->get('module_usage', 0);
$authorAvatarWidthSelect = $params->get('authorAvatarWidthSelect', 'custom');
$authorAvatarWidth = $params->get('authorAvatarWidth', 50);
$button = $params->get('button');
$imagebutton = $params->get('imagebutton');
$button_pos = $params->get('button_pos', 'left');
$button_text = $params->get('button_text', Joomla\CMS\Language\Text::_('K2_SEARCH'));
$text = $params->get('text', Joomla\CMS\Language\Text::_('K2_SEARCH'));
$searchItemId = $params->get('searchItemId', '');

// API
$document = Joomla\CMS\Factory::getDocument();
$app = Joomla\CMS\Factory::getApplication();

// Output
switch ($module_usage) {
    case '0':
        $months = modK2ToolsHelper::getArchive($params);
        if (count($months) > 0) {
            require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'archive');
        }

        break;

    case '1':
        // User avatar
        if ($authorAvatarWidthSelect == 'inherit') {
            $componentParams = Joomla\CMS\Component\ComponentHelper::getParams('com_k2');
            $avatarWidth = $componentParams->get('userImageWidth');
        } else {
            $avatarWidth = $authorAvatarWidth;
        }

        $authors = modK2ToolsHelper::getAuthors($params);
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'authors');
        break;

    case '2':
        $calendar = modK2ToolsHelper::calendar($params);
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'calendar');
        break;

    case '3':
        $breadcrumbs = modK2ToolsHelper::breadcrumbs($params);
        $path = $breadcrumbs[0];
        $title = $breadcrumbs[1];
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'breadcrumbs');
        break;

    case '4':
        $output = modK2ToolsHelper::treerecurse($params, 0, 0, true);
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'categories');
        break;

    case '5':
        echo modK2ToolsHelper::treeselectbox($params);
        break;

    case '6':
        $categoryFilter = modK2ToolsHelper::getSearchCategoryFilter($params);
        $action = Joomla\CMS\Router\Route::_(K2HelperRoute::getSearchRoute($searchItemId));
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'search');
        break;

    case '7':
        $tags = modK2ToolsHelper::tagCloud($params);
        if (count($tags) > 0) {
            require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'tags');
        }

        break;

    case '8':
        $customcode = modK2ToolsHelper::renderCustomCode($params);
        require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'customcode');
        break;

    case '9':
        $selectedTags = (array) $params->get('selectedTags');
        $selectedTagsLimit = (int) $params->get('selectedTagsLimit', 0);
        if ($selectedTags !== []) {
            require Joomla\CMS\Helper\ModuleHelper::getLayoutPath('mod_k2_tools', 'selected_tags');
        }

        break;
}
