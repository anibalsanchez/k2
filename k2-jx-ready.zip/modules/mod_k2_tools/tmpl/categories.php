<?php
/**
 * @version    2.x (rolling release)
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2009 - 2025 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL: https://gnu.org/licenses/gpl.html
 */

// no direct access
defined('_JEXEC') || die;

?>

<div id="k2ModuleBox<?php echo $module->id; ?>" class="k2CategoriesListBlock<?php if ($params->get('moduleclass_sfx')) {
    echo ' '.$params->get('moduleclass_sfx');
} ?>">
    <?php echo $output; ?>
</div>
