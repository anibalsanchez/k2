<?php
/**
 * @version    2.x (rolling release)
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2009 - 2025 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL: https://gnu.org/licenses/gpl.html
 */

// no direct access
defined('_JEXEC') || die;

?>

<?php if (count($selectedTags) > 0): ?>
<div id="k2ModuleBox<?php echo $module->id; ?>" class="k2SelectedTagsBlock<?php if ($params->get('moduleclass_sfx')) {
    echo ' '.$params->get('moduleclass_sfx');
} ?>">
    <ul>
        <?php foreach ($selectedTags as $key => $tag): ?>
        <?php if ($selectedTagsLimit > 0 && ($key + 1) > $selectedTagsLimit) {
            break;
        } ?>
        <li>
            <a href="<?php echo Joomla\CMS\Router\Route::_(K2HelperRoute::getTagRoute(urldecode($tag))); ?>"><?php echo urldecode($tag); ?></a>
        </li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>
