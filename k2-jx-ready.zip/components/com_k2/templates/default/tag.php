<?php
/**
 * @version    2.x (rolling release)
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2009 - 2025 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL: https://gnu.org/licenses/gpl.html
 */

// no direct access
defined('_JEXEC') || die;

?>

<!-- Start K2 Tag Layout -->
<div id="k2Container" class="tagView<?php if ($this->params->get('pageclass_sfx')) {
    echo ' '.$this->params->get('pageclass_sfx');
} ?>">
    <?php if ($this->params->get('show_page_title')): ?>
    <!-- Page title -->
    <div class="componentheading<?php echo $this->params->get('pageclass_sfx'); ?>">
        <?php echo $this->escape($this->params->get('page_title')); ?>
    </div>
    <?php endif; ?>

    <?php if ($this->params->get('tagName', 1)): ?>
    <!-- Title for tag listings -->
    <h1><?php echo Joomla\CMS\Language\Text::_('K2_DISPLAYING_ITEMS_BY_TAG'); ?> <?php echo $this->title; ?></h1>
    <?php endif; ?>

    <?php /* if (!empty($this->description)): ?>
    <!-- Custom description for tag listings -->
    <p class="tagDescription"><?php echo $this->description; ?></p>
    <?php endif; */ ?>

    <?php if ($this->params->get('tagFeedIcon', 1)): ?>
    <!-- RSS feed icon -->
    <div class="k2FeedIcon">
        <a href="<?php echo $this->feed; ?>" title="<?php echo Joomla\CMS\Language\Text::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?>">
            <span><?php echo Joomla\CMS\Language\Text::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?></span>
        </a>
        <div class="clr"></div>
    </div>
    <?php endif; ?>

    <?php if (isset($this->items) && count($this->items)): ?>
    <div class="tagItemList">
        <?php foreach ($this->items as $item): ?>
        <!-- Start K2 Item Layout -->
        <div class="tagItemView">
            <div class="tagItemHeader">
                <?php if ($item->params->get('tagItemDateCreated', 1)): ?>
                <!-- Date created -->
                <span class="tagItemDateCreated">
                    <?php echo Joomla\CMS\HTML\HTMLHelper::_('date', $item->created, Joomla\CMS\Language\Text::_('K2_DATE_FORMAT_LC2')); ?>
                </span>
                <?php endif; ?>

                <?php if ($item->params->get('tagItemTitle', 1)): ?>
                <!-- Item title -->
                <h2 class="tagItemTitle">
                    <?php if ($item->params->get('tagItemTitleLinked', 1)): ?>
                    <a href="<?php echo $item->link; ?>"><?php echo $item->title; ?></a>
                    <?php else: ?>
                    <?php echo $item->title; ?>
                    <?php endif; ?>
                </h2>
                <?php endif; ?>
            </div>

            <div class="tagItemBody">
                <?php if ($item->params->get('tagItemImage', 1) && !empty($item->imageGeneric)): ?>
                <!-- Item Image -->
                <div class="tagItemImageBlock">
                    <span class="tagItemImage">
                        <a href="<?php echo $item->link; ?>" title="<?php if (!empty($item->image_caption)) {
                            echo K2HelperUtilities::cleanHtml($item->image_caption);
                        } else {
                            echo K2HelperUtilities::cleanHtml($item->title);
                        } ?>">
                            <img src="<?php echo $item->imageGeneric; ?>" alt="<?php if (!empty($item->image_caption)) {
                                echo K2HelperUtilities::cleanHtml($item->image_caption);
                            } else {
                                echo K2HelperUtilities::cleanHtml($item->title);
                            } ?>" style="width:<?php echo $item->params->get('itemImageGeneric'); ?>px;height:auto;" />
                        </a>
                    </span>
                    <div class="clr"></div>
                </div>
                <?php endif; ?>

                <?php if ($item->params->get('tagItemIntroText', 1)): ?>
                <!-- Item introtext -->
                <div class="tagItemIntroText">
                    <?php echo $item->introtext; ?>
                </div>
                <?php endif; ?>

                <div class="clr"></div>
            </div>

            <div class="clr"></div>

            <?php if ($item->params->get('tagItemExtraFields', 0) && isset($item->extra_fields) && count($item->extra_fields)): ?>
            <!-- Item extra fields -->
            <div class="tagItemExtraFields">
                <h4><?php echo Joomla\CMS\Language\Text::_('K2_ADDITIONAL_INFO'); ?></h4>
                <ul>
                    <?php foreach ($item->extra_fields as $key => $extraField): ?>
                    <?php if ($extraField->value != ''): ?>
                    <li class="<?php echo ($key % 2 !== 0) ? 'odd' : 'even'; ?> type<?php echo ucfirst($extraField->type); ?> group<?php echo $extraField->group; ?> alias<?php echo ucfirst($extraField->alias); ?>">
                        <?php if ($extraField->type == 'header'): ?>
                        <h4 class="tagItemExtraFieldsHeader"><?php echo $extraField->name; ?></h4>
                        <?php else: ?>
                        <span class="tagItemExtraFieldsLabel"><?php echo $extraField->name; ?></span>
                        <span class="tagItemExtraFieldsValue"><?php echo $extraField->value; ?></span>
                        <?php endif; ?>
                    </li>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
                <div class="clr"></div>
            </div>
            <?php endif; ?>

            <?php if ($item->params->get('tagItemCategory')): ?>
            <!-- Item category name -->
            <div class="tagItemCategory">
                <span><?php echo Joomla\CMS\Language\Text::_('K2_PUBLISHED_IN'); ?></span>
                <a href="<?php echo $item->category->link; ?>"><?php echo $item->category->name; ?></a>
            </div>
            <?php endif; ?>

            <?php if ($item->params->get('tagItemTags', 1) && isset($item->tags) && count($item->tags)): ?>
            <!-- Item tags -->
            <div class="tagItemTagsBlock">
                <span><?php echo Joomla\CMS\Language\Text::_('K2_TAGGED_UNDER'); ?></span>
                <ul class="tagItemTags">
                    <?php foreach ($item->tags as $tag): ?>
                    <li><a href="<?php echo $tag->link; ?>"><?php echo $tag->name; ?></a></li>
                    <?php endforeach; ?>
                </ul>
                <div class="clr"></div>
            </div>
            <?php endif; ?>

            <?php if ($item->params->get('tagItemReadMore')): ?>
            <!-- Item "read more..." link -->
            <div class="tagItemReadMore">
                <a class="k2ReadMore" href="<?php echo $item->link; ?>">
                    <?php echo Joomla\CMS\Language\Text::_('K2_READ_MORE'); ?>
                </a>
            </div>
            <?php endif; ?>

            <div class="clr"></div>
        </div>
        <!-- End K2 Item Layout -->
        <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($this->pagination->getPagesLinks()): ?>
    <div class="k2Pagination">
        <div class="k2PaginationLinks">
            <?php echo $this->pagination->getPagesLinks(); ?>
        </div>
        <div class="k2PaginationCounter">
            <?php echo $this->pagination->getPagesCounter(); ?>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<!-- End K2 Tag Layout -->
