<?php
/**
 * @version    2.x (rolling release)
 * @author     JoomlaWorks https://www.joomlaworks.net
 * @copyright  Copyright (c) 2009 - 2025 JoomlaWorks Ltd. All rights reserved.
 * @license    GNU/GPL: https://gnu.org/licenses/gpl.html
 */

// no direct access
defined('_JEXEC') || die;

?>

<!-- Start K2 Category Layout -->
<div id="k2Container" class="itemListView<?php if ($this->params->get('pageclass_sfx')) {
    echo ' '.$this->params->get('pageclass_sfx');
} ?>">
    <?php if ($this->params->get('show_page_title')): ?>
    <!-- Page title -->
    <div class="componentheading<?php echo $this->params->get('pageclass_sfx'); ?>">
        <?php echo $this->escape($this->params->get('page_title')); ?>
    </div>
    <?php endif; ?>

    <?php if ($this->params->get('catFeedIcon')): ?>
    <!-- RSS feed icon -->
    <div class="k2FeedIcon">
        <a href="<?php echo $this->feed; ?>" title="<?php echo Joomla\CMS\Language\Text::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?>">
            <span><?php echo Joomla\CMS\Language\Text::_('K2_SUBSCRIBE_TO_THIS_RSS_FEED'); ?></span>
        </a>
        <div class="clr"></div>
    </div>
    <?php endif; ?>

    <?php if (isset($this->category) || ($this->params->get('subCategories') && isset($this->subCategories) && count($this->subCategories))): ?>
    <!-- Blocks for current category and subcategories -->
    <div class="itemListCategoriesBlock">
        <?php if (isset($this->category) && ($this->params->get('catImage') || $this->params->get('catTitle') || $this->params->get('catDescription') || $this->category->event->K2CategoryDisplay)): ?>
        <!-- Category block -->
        <div class="itemListCategory">
            <?php if (isset($this->addLink)): ?>
            <!-- Item add link -->
            <span class="catItemAddLink">
                <a data-k2-modal="edit" href="<?php echo $this->addLink; ?>">
                    <?php echo Joomla\CMS\Language\Text::_('K2_ADD_A_NEW_ITEM_IN_THIS_CATEGORY'); ?>
                </a>
            </span>
            <?php endif; ?>

            <?php if ($this->params->get('catImage') && $this->category->image): ?>
            <!-- Category image -->
            <img alt="<?php echo K2HelperUtilities::cleanHtml($this->category->name); ?>" src="<?php echo $this->category->image; ?>" style="width:<?php echo $this->params->get('catImageWidth'); ?>px;height:auto;" />
            <?php endif; ?>

            <?php if ($this->params->get('catTitle')): ?>
            <!-- Category title -->
            <h2><?php echo $this->category->name; ?><?php if ($this->params->get('catTitleItemCounter')) {
                echo ' ('.$this->pagination->total.')';
            } ?></h2>
            <?php endif; ?>

            <?php if ($this->params->get('catDescription')): ?>
            <!-- Category description -->
            <div><?php echo $this->category->description; ?></div>
            <?php endif; ?>

            <!-- K2 Plugins: K2CategoryDisplay -->
            <?php echo $this->category->event->K2CategoryDisplay; ?>

            <div class="clr"></div>
        </div>
        <?php endif; ?>

        <?php if ($this->params->get('subCategories') && isset($this->subCategories) && count($this->subCategories)): ?>
        <!-- Subcategories -->
        <div class="itemListSubCategories">
            <h3><?php echo Joomla\CMS\Language\Text::_('K2_CHILDREN_CATEGORIES'); ?></h3>

            <?php foreach ($this->subCategories as $key=>$subCategory): ?>
            <?php
            // Define a CSS class for the last container on each row
            $lastContainer = ($key + 1) % $this->params->get('subCatColumns') == 0 ? ' subCategoryContainerLast' : '';
                ?>
            <div class="subCategoryContainer<?php echo $lastContainer; ?>"<?php echo (count($this->subCategories) == 1) ? '' : ' style="width:'.number_format(100 / $this->params->get('subCatColumns'), 1).'%;"'; ?>>
                <div class="subCategory">
                    <?php if ($this->params->get('subCatImage') && $subCategory->image): ?>
                    <!-- Subcategory image -->
                    <a class="subCategoryImage" href="<?php echo $subCategory->link; ?>">
                        <img alt="<?php echo K2HelperUtilities::cleanHtml($subCategory->name); ?>" src="<?php echo $subCategory->image; ?>" />
                    </a>
                    <?php endif; ?>

                    <?php if ($this->params->get('subCatTitle')): ?>
                    <!-- Subcategory title -->
                    <h2>
                        <a href="<?php echo $subCategory->link; ?>">
                            <?php echo $subCategory->name; ?><?php if ($this->params->get('subCatTitleItemCounter')) {
                                echo ' ('.$subCategory->numOfItems.')';
                            } ?>
                        </a>
                    </h2>
                    <?php endif; ?>

                    <?php if ($this->params->get('subCatDescription')): ?>
                    <!-- Subcategory description -->
                    <div><?php echo $subCategory->description; ?></div>
                    <?php endif; ?>

                    <!-- Subcategory more... -->
                    <a class="subCategoryMore" href="<?php echo $subCategory->link; ?>">
                        <?php echo Joomla\CMS\Language\Text::_('K2_VIEW_ITEMS'); ?>
                    </a>

                    <div class="clr"></div>
                </div>
            </div>
            <?php if (($key + 1) % ($this->params->get('subCatColumns')) == 0): ?>
            <div class="clr"></div>
            <?php endif; ?>
            <?php endforeach; ?>

            <div class="clr"></div>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ((isset($this->leading) || isset($this->primary) || isset($this->secondary) || isset($this->links)) && (count($this->leading) || count($this->primary) || count($this->secondary) || count($this->links))): ?>
    <!-- Item list -->
    <div class="itemList">
        <?php if (isset($this->leading) && count($this->leading)): ?>
        <!-- Leading items -->
        <div id="itemListLeading">
            <?php foreach ($this->leading as $key=>$item): ?>
            <?php
            // Define a CSS class for the last container on each row
            if ((($key + 1) % ($this->params->get('num_leading_columns')) == 0) || count($this->leading) < $this->params->get('num_leading_columns')) {
                $lastContainer = ' itemContainerLast';
            } else {
                $lastContainer = '';
            }
                ?>
            <div class="itemContainer<?php echo $lastContainer; ?>"<?php echo (count($this->leading) == 1) ? '' : ' style="width:'.number_format(100 / $this->params->get('num_leading_columns'), 1).'%;"'; ?>>
                <?php
                        // Load category_item.php by default
                        $this->item = $item;
                echo $this->loadTemplate('item');
                ?>
            </div>
            <?php if (($key + 1) % ($this->params->get('num_leading_columns')) == 0): ?>
            <div class="clr"></div>
            <?php endif; ?>
            <?php endforeach; ?>
            <div class="clr"></div>
        </div>
        <?php endif; ?>

        <?php if (isset($this->primary) && count($this->primary)): ?>
        <!-- Primary items -->
        <div id="itemListPrimary">
            <?php foreach ($this->primary as $key=>$item): ?>
            <?php
            // Define a CSS class for the last container on each row
            if ((($key + 1) % ($this->params->get('num_primary_columns')) == 0) || count($this->primary) < $this->params->get('num_primary_columns')) {
                $lastContainer = ' itemContainerLast';
            } else {
                $lastContainer = '';
            }
                ?>
            <div class="itemContainer<?php echo $lastContainer; ?>"<?php echo (count($this->primary) == 1) ? '' : ' style="width:'.number_format(100 / $this->params->get('num_primary_columns'), 1).'%;"'; ?>>
                <?php
                        // Load category_item.php by default
                        $this->item = $item;
                echo $this->loadTemplate('item');
                ?>
            </div>
            <?php if (($key + 1) % ($this->params->get('num_primary_columns')) == 0): ?>
            <div class="clr"></div>
            <?php endif; ?>
            <?php endforeach; ?>
            <div class="clr"></div>
        </div>
        <?php endif; ?>

        <?php if (isset($this->secondary) && count($this->secondary)): ?>
        <!-- Secondary items -->
        <div id="itemListSecondary">
            <?php foreach ($this->secondary as $key=>$item): ?>
            <?php
            // Define a CSS class for the last container on each row
            if ((($key + 1) % ($this->params->get('num_secondary_columns')) == 0) || count($this->secondary) < $this->params->get('num_secondary_columns')) {
                $lastContainer = ' itemContainerLast';
            } else {
                $lastContainer = '';
            }
                ?>
            <div class="itemContainer<?php echo $lastContainer; ?>"<?php echo (count($this->secondary) == 1) ? '' : ' style="width:'.number_format(100 / $this->params->get('num_secondary_columns'), 1).'%;"'; ?>>
                <?php
                        // Load category_item.php by default
                        $this->item = $item;
                echo $this->loadTemplate('item');
                ?>
            </div>
            <?php if (($key + 1) % ($this->params->get('num_secondary_columns')) == 0): ?>
            <div class="clr"></div>
            <?php endif; ?>
            <?php endforeach; ?>
            <div class="clr"></div>
        </div>
        <?php endif; ?>

        <?php if (isset($this->links) && count($this->links)): ?>
        <!-- Link items -->
        <div id="itemListLinks">
            <h4><?php echo Joomla\CMS\Language\Text::_('K2_MORE'); ?></h4>
            <?php foreach ($this->links as $key=>$item): ?>
            <?php
            // Define a CSS class for the last container on each row
            if ((($key + 1) % ($this->params->get('num_links_columns')) == 0) || count($this->links) < $this->params->get('num_links_columns')) {
                $lastContainer = ' itemContainerLast';
            } else {
                $lastContainer = '';
            }
                ?>
            <div class="itemContainer<?php echo $lastContainer; ?>"<?php echo (count($this->links) == 1) ? '' : ' style="width:'.number_format(100 / $this->params->get('num_links_columns'), 1).'%;"'; ?>>
                <?php
                        // Load category_item.php by default
                        $this->item = $item;
                echo $this->loadTemplate('item');
                ?>
            </div>
            <?php if (($key + 1) % ($this->params->get('num_links_columns')) == 0): ?>
            <div class="clr"></div>
            <?php endif; ?>
            <?php endforeach; ?>
            <div class="clr"></div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if ($this->pagination->getPagesLinks()): ?>
    <div class="k2Pagination">
        <?php if ($this->params->get('catPagination', 1)): ?>
        <div class="k2PaginationLinks">
            <?php echo $this->pagination->getPagesLinks(); ?>
        </div>
        <?php endif; ?>
        <?php if ($this->params->get('catPaginationResults', 1)): ?>
        <div class="k2PaginationCounter">
            <?php echo $this->pagination->getPagesCounter(); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<!-- End K2 Category Layout -->
